import ExclusiveTravelPackagesSlider from "@/components/slider/exclusive-travel-packages-slider";

const ExclusiveTravelPackages = () => {
    return (
        <>
            <ExclusiveTravelPackagesSlider />
        </>
    );
};

export default ExclusiveTravelPackages;
