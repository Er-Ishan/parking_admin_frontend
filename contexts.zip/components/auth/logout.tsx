"use client";

import { useRouter } from "next/navigation";

export default function Logout() {
  const router = useRouter();

  const logout = async () => {
    await fetch(
      `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/session/logout`,
      {
        method: "POST",
        credentials: "include", // 🔴 REQUIRED
      }
    );

    router.replace("/auth/login");
  };

  return (
    <button
      onClick={logout}
      className="text-red-600 hover:text-red-800 font-semibold"
    >
      Logout
    </button>
  );
}
