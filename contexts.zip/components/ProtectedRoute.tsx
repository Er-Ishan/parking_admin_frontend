"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function ProtectedRoute({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const [checking, setChecking] = useState(true);
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/session/check`, {
      credentials: "include",
    })
      .then((res) => {
        if (!res.ok) {
          router.replace("/auth/login");
        } else {
          setAuthorized(true);
        }
      })
      .finally(() => {
        setChecking(false);
      });
  }, [router]);

  return (
    <>
      {/* ✅ ALWAYS render children (never unmount inputs) */}
      {children}

      {/* ⛔ overlay instead of unmount */}
      {checking && (
        <div className="fixed inset-0 bg-white z-50 flex items-center justify-center">
          Loading...
        </div>
      )}
    </>
  );
}
