import { StaticImageData } from 'next/image';

export interface StaticImg {
    image: StaticImageData;
}